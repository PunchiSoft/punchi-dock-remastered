# Temas de ejemplo para Punchi Dock

Este directorio reúne temas JSON listos para importar en Punchi Dock. Sirve
como catálogo de ejemplo, punto de partida para personalizaciones y referencia
del formato soportado; no es necesario editar ni copiar archivos manualmente
en la carpeta de configuración de Plasma.

Los mismos temas se entregan comprimidos en `Themes demo/` para quien descargue
el repositorio y prefiera importar el catálogo completo. Esa carpeta existe
para distribuir los ejemplos de forma cómoda y revisable: se conserva en Git,
pero queda fuera del paquete `.plasmoid` y no se instala automáticamente.

## Uso rápido

1. Abra la configuración de Punchi Dock y entre en **Apariencia**.
2. En **Tema de fondo del dock**, elija **Tema JSON externo**.
3. Pulse **Importar…** y seleccione **Importar carpeta…**.
4. Si trabaja desde el repositorio, seleccione `docs/themes/`. Si descargó el
   paquete demo, descomprímalo y seleccione la carpeta `themes/` resultante.
5. Elija el tema importado en el selector y aplique la configuración.

Los temas externos se aplican únicamente al dock flotante. Para volver al
aspecto nativo, seleccione **Tema Plasma** desde el mismo selector o el menú
contextual del dock. Punchi Dock valida cada JSON y guarda una copia propia en
su biblioteca de usuario; puede eliminar un tema importado desde Apariencia
sin modificar estos archivos de ejemplo.

Los JSON no ejecutan código, no incluyen scripts, recursos remotos ni rutas de
archivos. Solo describen propiedades visuales que Punchi Dock valida antes de
aceptarlas.

## Orientación vertical

Los fondos `flat`, incluidos los animados mediante `paletteFlow`, adaptan
automáticamente el eje del gradiente al pasar el dock flotante a vertical. Los
separadores temáticos `capsule` también cambian de eje como los separadores
nativos. No hacen falta variantes del mismo JSON para cada orientación.

## Origen del catálogo

Los ejemplos adaptan las propuestas visuales de:

```text
docs/guias-usuario/punchi-dock-24-propuestas-3d-2d.html
```

El HTML es únicamente una guía visual. Punchi Dock no carga ni ejecuta su HTML, CSS o JavaScript.

## Catálogo disponible

`schemaVersion: 1` admite el renderer 2D estable (`"flat"`) y una primera
iteración experimental 2.5D (`"shelf"`). `schemaVersion: 2` conserva ambos y
añade el renderer parametrizado de siluetas (`"shaped"`).

### Temas de silueta parametrizada

| Ejemplo | Archivo | Adaptación |
|---|---|---|
| 25. Onda suave | `shaped/onda-suave/25_onda_suave_shaped.json` | Ondulación alternada sobre los bordes largos |
| 26. Burbujas orgánicas | `shaped/burbujas/26_burbujas_shaped.json` | Arcos repetidos hacia el exterior |
| 27. Esquinas cortadas | `shaped/esquinas-cortadas/27_esquinas_cortadas_shaped.json` | Silueta octogonal con cortes proporcionales |

### Tema experimental 2.5D

| Propuesta | Archivo | Adaptación |
|---|---|---|
| 1. Cristal integrado 2.5D | `2.5d/cristal-integrado/01_cristal_integrado_2_5d.json` | Repisa inclinada, canto fino, rim luminoso y separador integrado |
| 2. Madera barnizada 2.5D | `2.5d/madera-barnizada/02_madera_barnizada_2_5d.json` | Repisa cálida, canto moderado y separador de madera |
| 3. Acero industrial 2.5D | `2.5d/acero-industrial/03_acero_industrial_2_5d.json` | Metal estratificado, canto moderado y separador de seguridad |
| 4. Obsidiana 2.5D | `2.5d/obsidiana/04_obsidiana_2_5d.json` | Superficie negra, canto fino y separador cian con glow |
| 5. Marco neón 2.5D | `2.5d/marco-neon/05_marco_neon_2_5d.json` | Estructura oscura con borde, rim y separador luminosos |

Los cinco temas forman el catálogo experimental inicial. Comparten el mismo
renderer para comparar materiales y dirección artística sin alterar la
geometría base.

### Temas 2D estables

La carpeta conserva las doce propuestas 2D del prototipo:

| Propuesta | Archivo | Adaptación |
|---|---|---|
| 13. Cristal Plasma | `2d/cristal-plasma/13_cristal_plasma_2d.json` | Transparencia, borde claro y separador luminoso tenue |
| 14. Cristal biselado | `2d/cristal-biselado/14_cristal_biselado_2d.json` | Gradiente con luces y separador biselado |
| 15. Madera plana | `2d/madera-plana/15_madera_plana_2d.json` | Gradiente de madera y separador ancho |
| 16. Obsidiana 2D | `2d/obsidiana/16_obsidiana_2d.json` | Gradiente oscuro y rombo cian con glow |
| 17. Marco neón | `2d/marco-neon/17_marco_neon_2d.json` | Fondo técnico, contorno y separador neón |
| 18. Burbujas | `2d/burbujas/18_burbujas_2d.json` | Forma redondeada y separador circular |
| 19. Cerámica 2D | `2d/ceramica/19_ceramica_2d.json` | Superficie clara y anillo cerámico |
| 20. Industrial plano | `2d/industrial-plano/20_industrial_plano_2d.json` | Metal oscuro y chevrón amarillo de seguridad |
| 21. Tela técnica | `2d/tela-tecnica/21_tela_tecnica_2d.json` | Base textil aproximada y línea doble técnica |
| 22. Holográfico 2D | `2d/holografico/22_holografico_2d.json` | Gradiente multicolor y estrella holográfica |
| 23. Piedra plana | `2d/piedra-plana/23_piedra_plana_2d.json` | Gradiente mineral y separador ancho de piedra |
| 24. Segmentado | `2d/segmentado/24_segmentado_2d.json` | Superficie translúcida y cuadrado segmentador |
| 28. Flujo holográfico animado | `2d/flujo-holografico/28_flujo_holografico_animado_2d.json` | Paleta cian, azul, violeta y rosa con desplazamiento horizontal continuo |

Las propuestas 6–12 siguen pendientes del renderer 2.5D. No se convierten
artificialmente a 2D.

## Simplificaciones del renderer actual

El esquema actual conserva:

- color y transparencia;
- gradiente lineal horizontal o vertical;
- entre dos y ocho paradas;
- borde;
- radio;
- sombra exterior;
- solicitud declarativa de blur.
- separador global del tema con geometría, gradiente, borde, glow y patrón interno.
- renderer experimental `shelf` con repisa, canto frontal y rim.
- renderer `shaped` con presets de silueta controlados.

Todavía no representa:

- gradientes diagonales;
- patrones repetidos;
- texturas de madera, piedra, carbono o tela;
- sombras interiores;
- padding o tamaño de iconos;
- segmentación completa del fondo o de grupos de iconos;
- blur garantizado por KWin.

## Separadores temáticos

La sección opcional `separator` se aplica conjuntamente con el fondo a todos los
separadores que la persona ya tenga en el dock. El tema no inserta, elimina ni
mueve elementos.

Geometrías admitidas:

- `line`;
- `dot`;
- `square`;
- `capsule`;
- `star`;
- `diamond`;
- `ring`;
- `doubleLine`;
- `chevron`.

El catálogo es el mismo que ofrece el editor de separadores. `capsule` es el
identificador canónico de la cápsula redondeada; las configuraciones antiguas
del dock que todavía guardan `pill` se normalizan internamente.

### Muestras incluidas por forma

Las formas básicas `line`, `dot` y `capsule` continúan presentes en distintos
temas del catálogo. Las seis formas ampliadas tienen una muestra 2D dedicada:

| Forma | Valor de `separator.style` | Tema de muestra |
|---|---|---|
| Rombo | `diamond` | 16. Obsidiana 2D |
| Anillo | `ring` | 19. Cerámica 2D |
| Chevrón | `chevron` | 20. Industrial plano |
| Línea doble | `doubleLine` | 21. Tela técnica |
| Estrella | `star` | 22. Holográfico 2D |
| Cuadrado | `square` | 24. Segmentado |

Para crear una variante basta con cambiar el valor cerrado de `style`; no se
admiten nombres arbitrarios ni rutas a figuras externas:

```json
"separator": {
  "style": "diamond",
  "color": "#ff6de5ff",
  "thickness": 5,
  "lengthRatio": 0.93,
  "opacity": 1
}
```

`color`, `thickness`, `lengthRatio`, `opacity`, `radius`, `gradient`, `border`,
`glow` y `pattern` mantienen sus límites del esquema. La forma cambia de eje
automáticamente cuando corresponde; no hace falta duplicar el tema para un dock
vertical.

Patrones internos admitidos:

- `none`;
- `dashed`;
- `hazard`;
- `centerLine`.

Un tema sin la sección `separator`, un fondo Plasma o un dock integrado en un
panel conserva el separador nativo.

## Geometría del renderer `shelf`

La forma 2.5D se construye con polígonos internos acelerados por la escena Qt
Quick. Los temas sólo entregan medidas limitadas:

```json
"geometry": {
  "edgeDepth": 8,
  "rimThickness": 3,
  "horizontalInset": 6,
  "topDepthRatio": 0.76,
  "backInset": 16,
  "sideBevel": 4
}
```

- `topDepthRatio` controla cuánto espacio ocupa la cubierta desde el frente
  hacia atrás.
- `backInset` estrecha el borde posterior y genera la perspectiva trapezoidal.
- `sideBevel` recorta las esquinas inferiores del canto frontal.
- `edgeDepth` controla la altura del canto.
- `rimThickness` controla la línea que une cubierta y canto.
- `horizontalInset` separa la estructura de los límites de la ventana.

`topAngle` y `edgeAngle` se siguen aceptando para no romper temas importados
durante la primera prueba del renderer, pero la geometría nueva ya no depende
de esos campos.

## Geometría del renderer `shaped`

Los temas con silueta usan `schemaVersion: 2` y una sección `shape`:

```json
"shape": {
  "preset": "wave",
  "depthRatio": 0.1,
  "repetitions": 5,
  "phase": 0.1
}
```

- `preset` acepta `wave`, `bubbles` o `cutCorners`.
- `depthRatio` controla la profundidad respecto del lado menor del dock.
- `repetitions` controla cuántas ondas o burbujas se dibujan.
- `phase` desplaza el patrón alternado de `wave`.

El renderer genera internamente una ruta escalable. El tema no puede incluir
comandos SVG, código ni rutas a recursos. En orientación vertical, las ondas y
burbujas pasan automáticamente a los bordes largos laterales.

## Animación de gradiente `paletteFlow`

Los temas `flat` con `schemaVersion: 2` pueden solicitar un desplazamiento
continuo de la paleta:

```json
"animation": {
  "type": "paletteFlow",
  "duration": 16000,
  "direction": "forward"
}
```

- `duration` acepta entre `6000` y `60000` milisegundos;
- `direction` acepta `forward` o `reverse`;
- la primera y última parada del gradiente deben tener el mismo color;
- la animación se pausa cuando el fondo no está visible;
- si Plasma reduce las animaciones, el gradiente permanece estático;
- borde, sombra, separadores e iconos no se animan.

### Catálogo animado de referencia

| Tema | Archivo | Ciclo |
|---|---|---|
| 29. Aurora boreal | `2d/aurora-boreal/29_aurora_boreal_animada_2d.json` | Verde, turquesa, azul y violeta · 24 s |
| 30. Atardecer solar | `2d/atardecer-solar/30_atardecer_solar_animado_2d.json` | Amarillo, naranja, magenta y púrpura · 20 s inverso |
| 31. Océano profundo | `2d/oceano-profundo/31_oceano_profundo_animado_2d.json` | Azul profundo, cian y verde marino · 28 s |
| 32. Neón cyberpunk | `2d/neon-cyberpunk/32_neon_cyberpunk_animado_2d.json` | Cian, violeta, rosa y rojo · 12 s |
| 33. Lava psicodélica | `2d/lava-psicodelica/33_lava_psicodelica_animada_2d.json` | Rojo, naranja, amarillo y magenta · 10 s inverso |
| 34. Aceite iridiscente | `2d/aceite-iridiscente/34_aceite_iridiscente_animado_2d.json` | Verde, violeta, cobre y azul · 18 s |
| 35. Arcoíris pastel | `2d/arcoiris-pastel/35_arcoiris_pastel_animado_2d.json` | Rosa, melocotón, amarillo, turquesa y lavanda · 32 s |
| 36. Fantasma polar | `2d/fantasma-polar/36_fantasma_polar_animado_2d.json` | Blanco azulado, cian y violeta · 26 s inverso |
| 37. Matriz verde | `2d/matriz-verde/37_matriz_verde_animada_2d.json` | Verdes oscuros y eléctricos · 14 s |
| 38. Plasma eléctrico | `2d/plasma-electrico/38_plasma_electrico_animado_2d.json` | Azul, blanco, violeta y cian · 9 s inverso |

Los bordes y sombras de estos ejemplos usan únicamente las capacidades
estáticas actuales. No representan todavía un bisel degradado ni un borde
animado.

## Importación y biblioteca local

1. Abrir la configuración de Punchi Dock.
2. Entrar en `Apariencia`.
3. En `Tema de fondo del dock`, seleccionar `Tema JSON externo`.
4. Pulsar `Importar…` y elegir `Importar carpeta…`.
5. Seleccionar `docs/themes/` o la carpeta `themes/` extraída del paquete demo.
   Punchi Dock recorrerá `2d/`, `2.5d/`, `shaped/` y la carpeta individual de
   cada tema.
6. Aplicar la configuración.

También se mantiene `Importar archivo…` para incorporar un único JSON.

Punchi Dock guarda una copia validada en:

```text
QStandardPaths::GenericDataLocation/punchi-dock-remastered/themes/
```

En una instalación Linux habitual:

```text
~/.local/share/punchi-dock-remastered/themes/
```

Las importaciones nuevas se organizan por renderer y nombre seguro:

```text
themes/
├── 2d/<nombre-del-tema>/<id>.json
├── 2.5d/<nombre-del-tema>/<id>.json
└── shaped/<nombre-del-tema>/<id>.json
```

La biblioteca continúa reconociendo archivos planos instalados por versiones
anteriores. Desde Apariencia se puede eliminar un tema instalado mediante el
botón de papelera situado junto al selector.

## Distribución del catálogo

Los archivos de `docs/themes/`:

- no forman parte del `.plasmoid`;
- no se copian durante la compilación;
- están cubiertos por la exclusión de `docs/`;
- se distribuyen y descargan por separado mediante `Themes demo/`.

## Restricciones de `schemaVersion: 1`

- tamaño máximo: `64 KiB`;
- colores: `#RRGGBB` o `#AARRGGBB`;
- renderers permitidos: `"flat"` y `"shelf"`;
- radio entre `0` y `48`;
- borde entre `0` y `4`;
- sombra entre `0` y `8`;
- desplazamientos de sombra entre `-4` y `4`;
- grosor del separador entre `1` y `28`;
- longitud relativa del separador entre `0.2` y `1`;
- glow del separador entre `0` y `12`;
- ángulo superior 2.5D entre `35` y `75` grados;
- ángulo del canto entre `-45` y `-10` grados;
- profundidad del canto entre `8` y `28`; los ejemplos oficiales usan `8–9`
  para mantener una silueta ligera;
- profundidad relativa de la cubierta entre `0.3` y `0.8`;
- estrechamiento posterior entre `4` y `48`;
- bisel lateral entre `0` y `12`;
- sin imágenes, código, shaders ni recursos remotos.

## Restricciones adicionales de `schemaVersion: 2`

- mantiene las restricciones comunes de `schemaVersion: 1`;
- renderers permitidos: `"flat"`, `"shelf"` y `"shaped"`;
- presets de silueta: `"wave"`, `"bubbles"` y `"cutCorners"`;
- profundidad relativa entre `0.04` y `0.24`;
- repeticiones enteras entre `2` y `12`;
- fase entre `0` y `1`;
- no admite rutas SVG proporcionadas por el tema.
- la animación opcional `paletteFlow` se admite únicamente con `flat`;
- los ciclos animados deben durar entre `6000` y `60000` milisegundos;
- una paleta animada debe cerrar con el mismo color al inicio y al final.
