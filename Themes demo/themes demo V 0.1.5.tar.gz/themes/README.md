# Punchi Dock demo theme catalogue

This archive contains example JSON themes that can be imported into Punchi
Dock. They are data files only: they cannot run scripts, load external
resources, or change files outside Punchi Dock's theme library.

## Importing the catalogue

1. Open Punchi Dock configuration and select **Appearance**.
2. Under **Dock background theme**, select **External JSON theme**.
3. Select **Import…**, then choose **Import folder…**.
4. Select this `themes/` directory.
5. Choose one of the imported themes and apply the configuration.

The catalogue is organised by renderer:

- `2d/` contains flat themes.
- `2.5d/` contains experimental shelf-style themes.
- `shaped/` contains parametric silhouette themes.

Some flat themes include a continuous palette animation. Animated gradients
follow the dock axis when a floating dock is vertical.

## Editing a theme

Use the included JSON files as examples. Keep each theme declarative JSON:
supported properties describe the surface, shape, separators, and optional
palette animation. Punchi Dock validates every theme before importing it.
