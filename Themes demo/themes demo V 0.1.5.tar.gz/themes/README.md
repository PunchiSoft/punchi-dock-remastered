# Punchi Dock example themes

This directory contains JSON themes ready to import into Punchi Dock. It is an
example catalogue and format reference, not part of the runtime package.

The same themes are also distributed as a compressed catalogue in `Themes demo/`.
That directory is kept for convenient sharing and remains outside the `.plasmoid`
package and Plasma's configuration directory.

## Quick start

1. Open Punchi Dock settings and select **Appearance**.
2. Set **Dock background theme** to **External JSON theme**.
3. Choose **Import…**, then **Import folder…**.
4. Select `docs/themes/`, or the extracted `themes/` directory from the demo archive.
5. Select an imported theme and apply the configuration.

External themes apply only to the floating dock. Select **Plasma theme** to
restore the native appearance. Punchi Dock validates each JSON file and stores
a managed copy in the user's theme library.

Theme files are declarative JSON data: they cannot run scripts, load remote
resources, or provide filesystem paths. Only validated visual properties are
accepted.

## Available renderers

- `flat`: stable 2D backgrounds with gradients, borders, shadows, and themed separators.
- `shelf`: experimental 2.5D surfaces with a shelf, front edge, rim, and bounded geometry.
- `shaped`: experimental schema version 2 silhouettes using `wave`, `bubbles`, or `cutCorners` presets.

The catalogue includes stable 2D themes, five experimental 2.5D materials, and
three parametrized silhouettes. Animated `paletteFlow` examples are available
for `flat` schema version 2 themes. The complete catalogue and per-theme paths
are listed in [README.es.md](README.es.md), which is the Spanish companion.

## Themed separators

The optional `separator.style` field uses the same closed catalog as the item
editor: `line`, `dot`, `square`, `capsule`, `star`, `diamond`, `ring`,
`doubleLine`, and `chevron`. `capsule` is the canonical rounded-pill identifier;
older dock configurations that still store `pill` are normalized internally.

Separator patterns remain independent from geometry. Their supported values
are `none`, `dashed`, `hazard`, and `centerLine`.

### Included shape samples

The catalogue retains examples of the basic `line`, `dot`, and `capsule`
styles. The six extended shapes each have a dedicated stable 2D sample:

| Shape | `separator.style` | Sample theme |
|---|---|---|
| Diamond | `diamond` | 16. Obsidiana 2D |
| Ring | `ring` | 19. Cerámica 2D |
| Chevron | `chevron` | 20. Industrial plano |
| Double line | `doubleLine` | 21. Tela técnica |
| Star | `star` | 22. Holográfico 2D |
| Square | `square` | 24. Segmentado |

Use one of the closed `style` values when creating a variant. Arbitrary shape
names and external figure paths are rejected:

```json
"separator": {
  "style": "diamond",
  "color": "#ff6de5ff",
  "thickness": 5,
  "lengthRatio": 0.93,
  "opacity": 1
}
```

The remaining separator properties keep their schema bounds. Orientation-aware
shapes adapt automatically, so a separate vertical theme is not required.

## Orientation and storage

Flat gradients, animated palette flow, and capsule separators adapt their axis
automatically when the floating dock becomes vertical. No orientation-specific
JSON variants are required.

Imported themes are stored under:

```text
QStandardPaths::GenericDataLocation/punchi-dock-remastered/themes/
```

On a typical Linux installation this is:

```text
~/.local/share/punchi-dock-remastered/themes/
```

## Package and schema boundaries

Files in `docs/themes/` are not copied during the build, are excluded from the
`.plasmoid`, and are distributed separately through `Themes demo/`.

Schema version 1 supports `flat` and `shelf`; schema version 2 also supports
`shaped` and `paletteFlow` animation. Both versions enforce bounded dimensions,
colors, gradients, separators, geometry, and file size. Themes cannot include
images, code, shaders, SVG paths, or remote resources.
